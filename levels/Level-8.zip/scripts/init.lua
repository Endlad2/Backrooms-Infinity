log.info("Level 8 init")
generator.grid(2)
