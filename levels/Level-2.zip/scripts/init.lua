log.info("Level 2 init")
generator.grid(2)
