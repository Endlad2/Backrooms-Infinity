No third-party models bundled in this procedural prototype.
