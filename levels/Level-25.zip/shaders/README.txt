Level may use engine-global VHS/post effects. Custom WGSL can be added here.
