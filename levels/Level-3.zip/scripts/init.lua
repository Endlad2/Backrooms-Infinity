log.info("Level 3 init")
generator.grid(2)
