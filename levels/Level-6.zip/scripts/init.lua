log.info("Level 6 init")
generator.grid(2)
