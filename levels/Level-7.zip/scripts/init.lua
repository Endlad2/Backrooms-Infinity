log.info("Level 7 init")
generator.grid(2)
