-- init.lua
local templates = {
  { id = "warehouse", weight = 5 },
  { id = "storage",   weight = 2 },
  { id = "corridor",  weight = 2 },
  { id = "meg_base",  weight = 1 },
}
local total = 0
for _, t in ipairs(templates) do total = total + t.weight end
local function pick(px, py, pz)
  local h = math.abs((px * 73856093) ~ (pz * 19349663) ~ (py * 83492791))
  local roll = h % total
  local acc = 0
  for _, t in ipairs(templates) do
    acc = acc + t.weight
    if roll < acc then return t.id end
  end
  return "warehouse"
end
generator.custom(function(px, py, pz)
  local size = 16
  local cx = math.floor(px / size)
  local cz = math.floor(pz / size)
  local out = {}
  for dx = -2, 2 do
    for dz = -2, 2 do
      table.insert(out, { chunk = pick(cx+dx, 0, cz+dz), x = cx+dx, y = 0, z = cz+dz })
    end
  end
  return out
end)
