log.info("Level 1 init")
generator.grid(2)
