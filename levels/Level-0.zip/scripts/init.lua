log.info("Level 0: detailed 64x64 infinite office grid; 8 solid-floor templates")
generator.grid(1)
