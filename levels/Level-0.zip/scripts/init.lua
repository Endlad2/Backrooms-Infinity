log.info("Level 0: initializing 64x64 infinite grid with 8 chunk templates")
generator.grid(2)
