This Level 0 pack currently relies on the engine's standard material path; no custom WGSL shader is required.
