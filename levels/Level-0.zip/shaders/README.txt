Level 0 uses the global VHS post-process. PBR is provided by Godot StandardMaterial3D.
