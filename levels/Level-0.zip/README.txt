Backrooms Infinity - Level 0

This package contains eight handcrafted 64x64 office-labyrinth chunk templates. All chunks have solid terrazzo floors: there are no parkour pits. Walls use a yellow-plaster PBR set, ceilings use acoustic tiles, and fluorescent fixtures are glTF models with embedded materials. Selected fixtures also spawn real runtime OmniLight3D lights through XML properties.

Material direction was chosen from the requested Terrazzo Tiles and Yellow Plaster look. Reference CC0 assets: https://polyhaven.com/a/terrazzo_tiles and https://polyhaven.com/a/yellow_plaster . The bundled maps are lightweight project-generated maps so the level ZIP stays small and self-contained.
