Backrooms Infinity — Level 0
----------------------------
Chunk size: 64 x 64 world units
Generator: infinite X/Z grid, streaming radius 2
Templates: 8
  1. classic_labyrinth
  2. long_corridors
  3. pillar_hall
  4. partition_rooms
  5. cross_junction
  6. dense_maze
  7. open_office
  8. pit_grid

The pit_grid template uses real missing floor tiles (not a fake black texture)
so the openings remain actual geometry gaps for physics/runtime handling.
