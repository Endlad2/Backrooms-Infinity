Backrooms Infinity Level 18 — Воспоминания

Source reference: https://www.backroomswiki.ru/level-18
Status: procedural prototype level pack. Geometry and textures in this ZIP were generated for this repository; no external 3D models are bundled.
Chunk coordinates are relative to each 64x64 chunk center.
