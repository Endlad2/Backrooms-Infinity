Backrooms Infinity Level 19 — Чердак

Source reference: https://www.backroomswiki.ru/level-19
Status: procedural prototype level pack. Geometry and textures in this ZIP were generated for this repository; no external 3D models are bundled.
Chunk coordinates are relative to each 64x64 chunk center.
