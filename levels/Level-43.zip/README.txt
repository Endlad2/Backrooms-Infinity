Backrooms Infinity Level 43 — Водный Мир

Source reference: https://www.backroomswiki.ru/level-43
Status: procedural prototype level pack. Geometry and textures in this ZIP were generated for this repository; no external 3D models are bundled.
Chunk coordinates are relative to each 64x64 chunk center.
