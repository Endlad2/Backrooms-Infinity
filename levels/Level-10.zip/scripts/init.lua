log.info("Level 10 init")
generator.grid(2)
